import { createSlice } from '@reduxjs/toolkit';
const slice = createSlice({
  name: 'user',
  initialState: { name: 'Asha Rao', email: 'asha.rao@example.com', phone: '9876543210', role: 'learner' },
  reducers: {
    setUser: (s, a) => { Object.assign(s, a.payload); },
    toggleRole: (s) => { s.role = s.role === 'learner' ? 'coordinator' : 'learner'; },
  },
});
export const { setUser, toggleRole } = slice.actions;
export default slice.reducer;
