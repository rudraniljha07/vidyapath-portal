import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import * as api from '../api';
export const loadEnrolments = createAsyncThunk('enrolments/load', () => api.getEnrolments());
export const submitEnrolment = createAsyncThunk('enrolments/submit', (body) => api.createEnrolment(body));
export const updateEnrolment = createAsyncThunk('enrolments/update', ({ id, status }) => api.patchEnrolment(id, { status }));
const slice = createSlice({
  name: 'enrolments',
  initialState: { items: [], status: 'idle', error: null },
  reducers: {},
  extraReducers: (b) => b
    .addCase(loadEnrolments.pending, (s) => { s.status = 'loading'; s.error = null; })
    .addCase(loadEnrolments.fulfilled, (s, a) => { s.status = 'succeeded'; s.items = a.payload; })
    .addCase(loadEnrolments.rejected, (s, a) => { s.status = 'failed'; s.error = a.error.message; })
    .addCase(submitEnrolment.fulfilled, (s, a) => { s.items.unshift(a.payload); })
    .addCase(updateEnrolment.fulfilled, (s, a) => { s.items = s.items.map((e) => (e.id === a.payload.id ? a.payload : e)); }),
});
export default slice.reducer;
