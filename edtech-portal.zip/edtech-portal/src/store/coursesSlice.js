import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import * as api from '../api';
export const fetchCourses = createAsyncThunk('courses/fetch', (qs) => api.getCourses(qs));
const slice = createSlice({
  name: 'courses',
  initialState: { items: [], total: 0, page: 1, pages: 1, status: 'idle', error: null, reqId: null },
  reducers: {},
  extraReducers: (b) => b
    .addCase(fetchCourses.pending, (s, a) => { s.status = 'loading'; s.error = null; s.reqId = a.meta.requestId; })
    // ignore responses from superseded requests (fast typing / filter changes)
    .addCase(fetchCourses.fulfilled, (s, a) => { if (a.meta.requestId === s.reqId) Object.assign(s, a.payload, { status: 'succeeded' }); })
    .addCase(fetchCourses.rejected, (s, a) => { if (a.meta.requestId === s.reqId) { s.status = 'failed'; s.error = a.error.message; } }),
});
export default slice.reducer;
