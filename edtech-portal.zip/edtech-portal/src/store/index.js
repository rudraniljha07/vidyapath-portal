import { configureStore } from '@reduxjs/toolkit';
import courses from './coursesSlice';
import enrolments from './enrolmentsSlice';
import user from './userSlice';
export const makeStore = () => configureStore({ reducer: { courses, enrolments, user } });
