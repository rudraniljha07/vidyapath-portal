import { CATEGORIES, LEVELS, MODES, CENTRES } from '../constants';
const topics = {
  'Engineering Entrance': ['JEE Main Crash Course', 'KCET Physics Mastery', 'JEE Advanced Problem Solving'],
  'Medical Entrance': ['NEET Biology Intensive', 'NEET Chemistry Revision', 'AIIMS Mock Test Series'],
  Foundation: ['Class 9 Maths Foundation', 'Class 10 Science Booster', 'Olympiad Reasoning Lab'],
  Coding: ['Python for Beginners', 'Web Development with React', 'Data Structures in Java'],
  Languages: ['Spoken English Fluency', 'IELTS Preparation', 'German A1 Starter'],
  Commerce: ['CA Foundation Accounting', 'CUET Commerce Prep', 'Business Maths & Statistics'],
};
const LONG = 'Integrated Five-Year Residential Programme for JEE Main, JEE Advanced, KCET and Olympiad Preparation with Weekly Mentorship and Parent Counselling Sessions';
// Deterministic seed with deliberate edge cases:
// id 4,8,... -> no image | id 5 -> broken image URL | id 7 -> very long title + full | id 14,21,28 -> full
export const courses = Array.from({ length: 30 }, (_, k) => {
  const i = k + 1;
  const category = CATEGORIES[i % 6];
  const topic = topics[category][Math.floor(i / 6) % 3];
  let image = i % 4 === 0 ? null : `/images/c${(i % 3) + 1}.svg`;
  if (i === 5) image = '/images/does-not-exist.png';
  const raw = 4000 + ((i * 1370) % 41000);
  return {
    id: i,
    title: i === 7 ? LONG : `${topic} · Batch ${String(i).padStart(2, '0')}`,
    category,
    level: LEVELS[i % 3],
    mode: MODES[(i + 1) % 3],
    centre: CENTRES[i % 5],
    fee: raw - (raw % 500),
    durationWeeks: 4 + (i % 5) * 4,
    seatsLeft: i % 7 === 0 ? 0 : 3 + ((i * 5) % 28),
    rating: +(3.6 + ((i * 7) % 14) / 10).toFixed(1),
    startDate: `2026-12-${String(1 + (i % 28)).padStart(2, '0')}`,
    instructor: ['Dr. Meera Nair', 'Prof. Karthik Gowda', 'Ms. Anjali Hegde', 'Mr. Rohan Shetty'][i % 4],
    image,
    description: `${topic} is a structured programme with weekly assessments, doubt-clearing sessions and printed study material, designed for learners in Bengaluru.`,
  };
});
export const seedEnrolments = [
  { id: 1, courseId: 1, courseTitle: courses[0].title, name: 'Asha Rao', email: 'asha.rao@example.com', phone: '9876543210', centre: 'Koramangala', batch: 'Weekend', status: 'Confirmed', createdAt: '2026-11-02' },
  { id: 2, courseId: 9, courseTitle: courses[8].title, name: 'Vikram Iyer', email: 'vikram@example.com', phone: '9123456780', centre: 'Indiranagar', batch: 'Weekday evening', status: 'Pending', createdAt: '2026-11-08' },
  { id: 3, courseId: 12, courseTitle: courses[11].title, name: 'Fatima Sheikh', email: 'fatima@example.com', phone: '9988776655', centre: 'Jayanagar', batch: 'Weekday morning', status: 'Pending', createdAt: '2026-11-10' },
];
