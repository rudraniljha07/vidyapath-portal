import { http, HttpResponse, delay } from 'msw';
import { courses, seedEnrolments } from './data';
import { PAGE_SIZE } from '../constants';
import { validateStep } from '../validators';

let enrolments = [...seedEnrolments];
let nextId = 100;
const latency = () => delay(import.meta.env.MODE === 'test' ? 0 : 350);
const err = (message, status) => HttpResponse.json({ message }, { status });

export const handlers = [
  http.get('*/api/courses', async ({ request }) => {
    await latency();
    const p = new URL(request.url).searchParams;
    if (p.get('fail')) return err('Server unavailable. Please try again.', 500);
    const q = (p.get('q') || '').trim().toLowerCase();
    let list = courses.filter((c) =>
      (!q || `${c.title} ${c.category} ${c.centre} ${c.instructor}`.toLowerCase().includes(q)) &&
      (!p.get('category') || c.category === p.get('category')) &&
      (!p.get('level') || c.level === p.get('level')) &&
      (!p.get('mode') || c.mode === p.get('mode')));
    const sorters = {
      'fee-asc': (a, b) => a.fee - b.fee, 'fee-desc': (a, b) => b.fee - a.fee,
      rating: (a, b) => b.rating - a.rating, start: (a, b) => a.startDate.localeCompare(b.startDate),
    };
    if (sorters[p.get('sort')]) list = [...list].sort(sorters[p.get('sort')]);
    const pages = Math.max(1, Math.ceil(list.length / PAGE_SIZE));
    const page = Math.min(Math.max(1, Number(p.get('page')) || 1), pages);
    return HttpResponse.json({ items: list.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE), total: list.length, page, pages });
  }),
  http.get('*/api/courses/:id', async ({ params }) => {
    await latency();
    const c = courses.find((x) => x.id === Number(params.id));
    return c ? HttpResponse.json(c) : err('Course not found.', 404);
  }),
  http.get('*/api/enrolments', async () => { await latency(); return HttpResponse.json(enrolments); }),
  http.post('*/api/enrolments', async ({ request }) => {
    await latency();
    const b = await request.json();
    const course = courses.find((x) => x.id === Number(b.courseId));
    if (!course) return err('Course not found.', 404);
    if (course.seatsLeft === 0) return err('This course is full.', 409);
    if (Object.keys({ ...validateStep(0, b), ...validateStep(1, b) }).length) return err('Invalid enrolment details.', 422);
    const e = { ...b, id: nextId++, courseId: course.id, courseTitle: course.title, status: 'Pending', createdAt: new Date().toISOString().slice(0, 10) };
    enrolments = [e, ...enrolments];
    return HttpResponse.json(e, { status: 201 });
  }),
  http.patch('*/api/enrolments/:id', async ({ params, request }) => {
    await latency();
    const b = await request.json();
    const i = enrolments.findIndex((x) => x.id === Number(params.id));
    if (i < 0) return err('Enrolment not found.', 404);
    enrolments[i] = { ...enrolments[i], ...b };
    return HttpResponse.json(enrolments[i]);
  }),
];
