const BASE = import.meta.env.MODE === 'test' ? 'http://localhost' : '';
async function req(path, opts) {
  const res = await fetch(BASE + path, { headers: { 'Content-Type': 'application/json' }, ...opts });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.message || `Request failed (${res.status})`);
  }
  return res.json();
}
export const getCourses = (qs) => req(`/api/courses?${qs}`);
export const getCourse = (id) => req(`/api/courses/${id}`);
export const getEnrolments = () => req('/api/enrolments');
export const createEnrolment = (b) => req('/api/enrolments', { method: 'POST', body: JSON.stringify(b) });
export const patchEnrolment = (id, b) => req(`/api/enrolments/${id}`, { method: 'PATCH', body: JSON.stringify(b) });
