import { lazy } from 'react';
import { Link, Route, Routes } from 'react-router-dom';
import Layout from './components/Layout';
import { EmptyState } from './components/States';
const Home = lazy(() => import('./pages/Home'));
const Courses = lazy(() => import('./pages/Courses'));
const CourseDetail = lazy(() => import('./pages/CourseDetail'));
const Enrol = lazy(() => import('./pages/Enrol'));
const Profile = lazy(() => import('./pages/Profile'));
const Admin = lazy(() => import('./pages/Admin'));
export default function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<Home />} />
        <Route path="courses" element={<Courses />} />
        <Route path="courses/:id" element={<CourseDetail />} />
        <Route path="courses/:id/enrol" element={<Enrol />} />
        <Route path="profile" element={<Profile />} />
        <Route path="admin" element={<Admin />} />
        <Route path="*" element={<EmptyState title="Page not found" action={<Link className="btn" to="/">Go home</Link>}>That page doesn’t exist.</EmptyState>} />
      </Route>
    </Routes>
  );
}
