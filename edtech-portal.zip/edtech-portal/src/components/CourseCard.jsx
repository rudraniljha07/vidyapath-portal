import { useState } from 'react';
import { Link } from 'react-router-dom';
import { money } from '../utils';
export default function CourseCard({ course: c }) {
  const [broken, setBroken] = useState(false);
  return (
    <article className="card">
      {c.image && !broken
        ? <img src={c.image} alt="" loading="lazy" width="320" height="180" onError={() => setBroken(true)} />
        : <div className="ph" aria-hidden="true">{c.category[0]}</div>}
      <div className="body">
        <p className="tag">{c.category} · {c.level}</p>
        <h3 className="clamp" title={c.title}><Link to={`/courses/${c.id}`}>{c.title}</Link></h3>
        <p className="meta">{c.mode} · {c.centre}</p>
        <p className="row"><strong>{money(c.fee)}</strong><span>★ {c.rating}</span></p>
        <p className={`badge ${c.seatsLeft === 0 ? 'full' : ''}`}>{c.seatsLeft === 0 ? 'Full' : `${c.seatsLeft} seats left`}</p>
      </div>
    </article>
  );
}
