import { Suspense, useEffect, useRef } from 'react';
import { Link, NavLink, Outlet, useLocation } from 'react-router-dom';
import { Loading } from './States';
export default function Layout() {
  const { pathname } = useLocation();
  const main = useRef(null);
  const first = useRef(true);
  // move focus to <main> on client-side navigation so keyboard/screen-reader users aren't stranded
  useEffect(() => { if (first.current) { first.current = false; return; } main.current?.focus(); }, [pathname]);
  return (
    <>
      <a className="skip" href="#main">Skip to main content</a>
      <header className="site-header">
        <div className="wrap bar">
          <Link to="/" className="brand">Vidya<span>Path</span></Link>
          <nav aria-label="Primary">
            <ul>
              <li><NavLink to="/courses">Courses</NavLink></li>
              <li><NavLink to="/profile">Profile</NavLink></li>
              <li><NavLink to="/admin">Admin</NavLink></li>
            </ul>
          </nav>
        </div>
      </header>
      <main id="main" tabIndex={-1} ref={main} className="wrap">
        <Suspense fallback={<Loading />}><Outlet /></Suspense>
      </main>
      <footer className="site-footer"><div className="wrap">© 2026 VidyaPath Coaching · Koramangala · Indiranagar · Jayanagar · Whitefield · HSR Layout</div></footer>
    </>
  );
}
