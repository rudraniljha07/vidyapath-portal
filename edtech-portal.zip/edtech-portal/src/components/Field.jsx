export function Field({ id, label, error, hint, as: As = 'input', children, ...props }) {
  const desc = [hint && `${id}-hint`, error && `${id}-err`].filter(Boolean).join(' ') || undefined;
  return (
    <div className="field">
      <label htmlFor={id}>{label}</label>
      {hint && <p id={`${id}-hint`} className="hint">{hint}</p>}
      <As id={id} name={id} aria-invalid={error ? 'true' : undefined} aria-describedby={desc} {...props}>{children}</As>
      {error && <p id={`${id}-err`} className="error">{error}</p>}
    </div>
  );
}
