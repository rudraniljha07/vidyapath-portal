export default function Pagination({ page, pages, onChange }) {
  if (pages <= 1) return null;
  return (
    <nav aria-label="Pagination" className="pager">
      <button className="btn secondary" disabled={page <= 1} onClick={() => onChange(page - 1)}>Previous</button>
      <span aria-current="page">Page {page} of {pages}</span>
      <button className="btn secondary" disabled={page >= pages} onClick={() => onChange(page + 1)}>Next</button>
    </nav>
  );
}
