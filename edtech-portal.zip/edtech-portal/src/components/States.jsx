import { Link } from 'react-router-dom';
export const Loading = ({ label = 'Loading' }) => (
  <div role="status" className="state"><span className="spinner" aria-hidden="true" /> {label}…</div>
);
export const EmptyState = ({ title, children, action }) => (
  <div className="state"><h2>{title}</h2><p>{children}</p>{action}</div>
);
export const ErrorState = ({ message, onRetry }) => (
  <div role="alert" className="state error-state">
    <h2>Something went wrong</h2><p>{message}</p>
    {onRetry && <button className="btn" onClick={onRetry}>Try again</button>}
    {!onRetry && <Link className="btn" to="/courses">Back to courses</Link>}
  </div>
);
