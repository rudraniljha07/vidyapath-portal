import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { Provider } from 'react-redux';
import { BrowserRouter } from 'react-router-dom';
import App from './App';
import { makeStore } from './store';
import './styles.css';
// The mock REST API (MSW) runs in the browser, so the static deploy needs no server.
async function boot() {
  const { worker } = await import('./mocks/browser');
  await worker.start({ onUnhandledRequest: 'bypass', quiet: true });
  createRoot(document.getElementById('root')).render(
    <StrictMode><Provider store={makeStore()}><BrowserRouter future={{ v7_startTransition: true, v7_relativeSplatPath: true }}><App /></BrowserRouter></Provider></StrictMode>,
  );
}
boot();
