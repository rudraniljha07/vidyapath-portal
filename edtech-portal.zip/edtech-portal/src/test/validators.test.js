import { validateStep } from '../validators';
const ok = { name: 'Asha Rao', email: 'a@b.co', phone: '9876543210', centre: 'HSR Layout', batch: 'Weekend', agree: true };
describe('validateStep', () => {
  it('accepts valid data', () => { [0, 1, 2].forEach((s) => expect(validateStep(s, ok)).toEqual({})); });
  it('rejects bad email and phone', () => {
    const e = validateStep(0, { ...ok, email: 'nope', phone: '12345' });
    expect(e.email).toBeTruthy(); expect(e.phone).toBeTruthy();
  });
  it('rejects phones not starting 6-9', () => { expect(validateStep(0, { ...ok, phone: '1234567890' }).phone).toBeTruthy(); });
  it('requires centre, batch and consent', () => {
    expect(Object.keys(validateStep(1, { ...ok, centre: '', batch: '' }))).toEqual(['centre', 'batch']);
    expect(validateStep(2, { ...ok, agree: false }).agree).toBeTruthy();
  });
});
