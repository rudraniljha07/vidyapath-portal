import { screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { renderApp } from './utils';

describe('Enrolment flow', () => {
  it('validates step 1 with accessible errors and focuses the first invalid field', async () => {
    renderApp('/courses/1/enrol');
    await screen.findByRole('heading', { name: 'Your details' });
    const email = screen.getByLabelText(/email address/i);
    await userEvent.clear(email); await userEvent.type(email, 'abc');
    await userEvent.click(screen.getByRole('button', { name: 'Next' }));
    expect(await screen.findByRole('alert')).toHaveTextContent(/fix 1 error/i);
    expect(email).toHaveAttribute('aria-invalid', 'true');
    expect(email).toHaveAccessibleDescription(/valid email/i);
    await vi.waitFor(() => expect(email).toHaveFocus());
  });
  it('completes all three steps and submits', async () => {
    renderApp('/courses/1/enrol');
    await screen.findByRole('heading', { name: 'Your details' });
    await userEvent.click(screen.getByRole('button', { name: 'Next' }));
    await userEvent.click(screen.getByRole('button', { name: 'Next' })); // blocked: needs centre + batch
    expect(await screen.findByRole('alert')).toHaveTextContent(/fix 2 errors/i);
    await userEvent.selectOptions(screen.getByLabelText(/preferred centre/i), 'HSR Layout');
    await userEvent.selectOptions(screen.getByLabelText(/batch timing/i), 'Weekend');
    await userEvent.click(screen.getByRole('button', { name: 'Next' }));
    expect(screen.getByRole('heading', { name: 'Review' })).toBeInTheDocument();
    await userEvent.click(screen.getByRole('button', { name: /submit enrolment/i }));
    expect(await screen.findByText(/must agree/i)).toBeInTheDocument();
    await userEvent.click(screen.getByLabelText(/i agree/i));
    await userEvent.click(screen.getByRole('button', { name: /submit enrolment/i }));
    expect(await screen.findByRole('heading', { name: /enrolment request received/i })).toBeInTheDocument();
  });
  it('blocks enrolment on a full course', async () => {
    renderApp('/courses/7/enrol');
    expect(await screen.findByRole('heading', { name: /fully booked/i })).toBeInTheDocument();
  });
});
describe('Course detail', () => {
  it('shows a not-found error', async () => {
    renderApp('/courses/9999');
    expect(await screen.findByRole('alert')).toHaveTextContent(/not found/i);
  });
  it('renders a very long title and hides enrolment for full courses', async () => {
    renderApp('/courses/7');
    expect(await screen.findByRole('heading', { level: 1, name: /Integrated Five-Year/ })).toBeInTheDocument();
    expect(screen.queryByRole('link', { name: /enrol now/i })).toBeNull();
  });
});
