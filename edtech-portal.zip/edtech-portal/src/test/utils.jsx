import { render } from '@testing-library/react';
import { Provider } from 'react-redux';
import { MemoryRouter } from 'react-router-dom';
import App from '../App';
import { makeStore } from '../store';
export function renderApp(route = '/') {
  const store = makeStore();
  return { store, ...render(<Provider store={store}><MemoryRouter initialEntries={[route]} future={{ v7_startTransition: true, v7_relativeSplatPath: true }}><App /></MemoryRouter></Provider>) };
}
