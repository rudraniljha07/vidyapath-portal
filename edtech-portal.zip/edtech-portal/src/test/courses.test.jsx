import { screen, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { http, HttpResponse } from 'msw';
import { server } from '../mocks/server';
import { renderApp } from './utils';

describe('Courses page', () => {
  it('shows a loading state then the first page of courses', async () => {
    renderApp('/courses');
    expect(await screen.findByText(/loading/i)).toBeInTheDocument();
    expect(await screen.findAllByRole('article')).toHaveLength(9);
    expect(screen.getByText('30 courses')).toBeInTheDocument();
  });
  it('filters by category via the URL-driven select', async () => {
    renderApp('/courses');
    await screen.findAllByRole('article');
    await userEvent.selectOptions(screen.getByLabelText('Category'), 'Coding');
    expect(await screen.findByText('5 courses')).toBeInTheDocument();
    screen.getAllByRole('article').forEach((a) => expect(within(a).getByText(/Coding/)).toBeInTheDocument());
  });
  it('shows an empty state for no matches and clears filters', async () => {
    renderApp('/courses');
    await screen.findAllByRole('article');
    await userEvent.type(screen.getByLabelText('Search'), 'zzzzqq');
    expect(await screen.findByText(/no courses match/i)).toBeInTheDocument();
    await userEvent.click(screen.getByRole('button', { name: /clear filters/i }));
    expect(await screen.findAllByRole('article')).toHaveLength(9);
  });
  it('paginates', async () => {
    renderApp('/courses');
    await screen.findAllByRole('article');
    expect(screen.getByText('Page 1 of 4')).toBeInTheDocument();
    await userEvent.click(screen.getByRole('button', { name: 'Next' }));
    expect(await screen.findByText('Page 2 of 4')).toBeInTheDocument();
  });
  it('sorts by fee ascending', async () => {
    renderApp('/courses?sort=fee-asc');
    const cards = await screen.findAllByRole('article');
    const fees = cards.map((c) => Number(within(c).getByText(/^₹/).textContent.replace(/[^\d]/g, '')));
    expect(fees).toEqual([...fees].sort((a, b) => a - b));
  });
  it('shows an error state with retry', async () => {
    server.use(http.get('*/api/courses', () => HttpResponse.json({ message: 'Server unavailable' }, { status: 500 })));
    renderApp('/courses');
    expect(await screen.findByRole('alert')).toHaveTextContent('Server unavailable');
    server.resetHandlers();
    await userEvent.click(screen.getByRole('button', { name: /try again/i }));
    expect(await screen.findAllByRole('article')).toHaveLength(9);
  });
  it('uses a placeholder (no <img>) when a course has no image', async () => {
    renderApp('/courses?q=Batch 04');
    const [card] = await screen.findAllByRole('article');
    expect(within(card).queryByRole('img')).toBeNull();
  });
});
