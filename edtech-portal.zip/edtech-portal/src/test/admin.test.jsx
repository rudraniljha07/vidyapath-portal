import { screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { renderApp } from './utils';
describe('Admin & profile', () => {
  it('guards the dashboard, then lets a coordinator update status', async () => {
    renderApp('/admin');
    expect(await screen.findByText(/coordinator access required/i)).toBeInTheDocument();
    await userEvent.click(screen.getByRole('button', { name: /switch to coordinator/i }));
    expect(await screen.findByRole('table')).toBeInTheDocument();
    const sel = await screen.findByLabelText('Status for Vikram Iyer');
    await userEvent.selectOptions(sel, 'Confirmed');
    expect(await screen.findByLabelText('Status for Vikram Iyer')).toHaveValue('Confirmed');
  });
  it("lists the learner's own enrolments on the profile", async () => {
    renderApp('/profile');
    expect(await screen.findByText('Confirmed')).toBeInTheDocument();
    expect(screen.queryByText(/Vikram/)).toBeNull();
  });
});
