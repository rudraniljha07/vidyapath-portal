import { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Link } from 'react-router-dom';
import { EmptyState, ErrorState, Loading } from '../components/States';
import { loadEnrolments } from '../store/enrolmentsSlice';
import { toggleRole } from '../store/userSlice';
import { useTitle } from '../utils';
export default function Profile() {
  useTitle('My profile');
  const dispatch = useDispatch();
  const user = useSelector((s) => s.user);
  const { items, status, error } = useSelector((s) => s.enrolments);
  useEffect(() => { dispatch(loadEnrolments()); }, [dispatch]);
  const mine = items.filter((e) => e.email === user.email);
  return (
    <>
      <h1>My profile</h1>
      <dl className="facts">
        <div><dt>Name</dt><dd className="wrap-text">{user.name}</dd></div>
        <div><dt>Email</dt><dd className="wrap-text">{user.email}</dd></div>
        <div><dt>Role</dt><dd>{user.role}</dd></div>
      </dl>
      <button className="btn secondary" onClick={() => dispatch(toggleRole())}>Switch to {user.role === 'learner' ? 'coordinator' : 'learner'} view</button>
      <h2>My enrolments</h2>
      {status === 'loading' && <Loading label="Loading enrolments" />}
      {status === 'failed' && <ErrorState message={error} onRetry={() => dispatch(loadEnrolments())} />}
      {status === 'succeeded' && mine.length === 0 && <EmptyState title="No enrolments yet" action={<Link className="btn" to="/courses">Find a course</Link>}>Courses you enrol in will appear here.</EmptyState>}
      {mine.length > 0 && <ul className="list">{mine.map((e) => (
        <li key={e.id}><Link to={`/courses/${e.courseId}`} className="wrap-text">{e.courseTitle}</Link> <span className={`badge ${e.status.toLowerCase()}`}>{e.status}</span><br /><small>{e.centre} · {e.batch}</small></li>))}</ul>}
    </>
  );
}
