import { Link, useNavigate } from 'react-router-dom';
import { CATEGORIES, CENTRES } from '../constants';
import { useTitle } from '../utils';
export default function Home() {
  useTitle('Courses in Bengaluru');
  const nav = useNavigate();
  const go = (e) => { e.preventDefault(); const q = new FormData(e.target).get('q').trim(); nav(q ? `/courses?q=${encodeURIComponent(q)}` : '/courses'); };
  return (
    <>
      <section className="hero">
        <h1>Learn with Bengaluru’s trusted coaching institute</h1>
        <p>Entrance exams, school foundation, coding and languages across five centres.</p>
        <form role="search" onSubmit={go} className="inline">
          <label htmlFor="home-q" className="sr-only">Search courses</label>
          <input id="home-q" name="q" type="search" placeholder="Try “NEET” or “Python”" />
          <button className="btn">Search</button>
        </form>
      </section>
      <section aria-labelledby="cats"><h2 id="cats">Browse by category</h2>
        <ul className="tiles">{CATEGORIES.map((c) => <li key={c}><Link to={`/courses?category=${encodeURIComponent(c)}`}>{c}</Link></li>)}</ul>
      </section>
      <section aria-labelledby="centres"><h2 id="centres">Our centres</h2><p>{CENTRES.join(' · ')}</p></section>
    </>
  );
}
