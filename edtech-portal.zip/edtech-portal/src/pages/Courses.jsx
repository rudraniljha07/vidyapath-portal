import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useSearchParams } from 'react-router-dom';
import { fetchCourses } from '../store/coursesSlice';
import { CATEGORIES, LEVELS, MODES, SORTS } from '../constants';
import CourseCard from '../components/CourseCard';
import Pagination from '../components/Pagination';
import { EmptyState, ErrorState, Loading } from '../components/States';
import { Field } from '../components/Field';
import { useTitle } from '../utils';

const Select = ({ id, label, value, options, onChange }) => (
  <Field id={id} label={label} as="select" value={value} onChange={(e) => onChange(e.target.value)}>
    {id !== 'sort' && <option value="">All</option>}
    {options.map((o) => (Array.isArray(o) ? <option key={o[0]} value={o[0]}>{o[1]}</option> : <option key={o}>{o}</option>))}
  </Field>
);

export default function Courses() {
  useTitle('Courses');
  const dispatch = useDispatch();
  const [sp, setSp] = useSearchParams();
  const { items, total, page, pages, status, error } = useSelector((s) => s.courses);
  const [term, setTerm] = useState(sp.get('q') || '');
  const qs = sp.toString();
  // URL is the source of truth for filters: shareable, back-button friendly
  useEffect(() => { dispatch(fetchCourses(qs)); }, [qs, dispatch]);
  const set = (k, v) => {
    const n = new URLSearchParams(sp);
    v ? n.set(k, v) : n.delete(k);
    if (k !== 'page') n.delete('page');
    setSp(n);
  };
  useEffect(() => { // debounce search
    const t = setTimeout(() => { if (term.trim() !== (sp.get('q') || '')) set('q', term.trim()); }, 300);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [term]);
  const clear = () => { setTerm(''); setSp({}); };

  return (
    <>
      <h1>Courses</h1>
      <form role="search" className="filters" onSubmit={(e) => e.preventDefault()}>
        <Field id="q" label="Search" type="search" value={term} placeholder="Course, centre or instructor" onChange={(e) => setTerm(e.target.value)} />
        <Select id="category" label="Category" value={sp.get('category') || ''} options={CATEGORIES} onChange={(v) => set('category', v)} />
        <Select id="level" label="Level" value={sp.get('level') || ''} options={LEVELS} onChange={(v) => set('level', v)} />
        <Select id="mode" label="Mode" value={sp.get('mode') || ''} options={MODES} onChange={(v) => set('mode', v)} />
        <Select id="sort" label="Sort by" value={sp.get('sort') || ''} options={SORTS} onChange={(v) => set('sort', v)} />
      </form>
      <p className="count" aria-live="polite">{status === 'succeeded' ? `${total} course${total === 1 ? '' : 's'}` : '\u00a0'}</p>
      {(status === 'loading' || status === 'idle') && <Loading label="Loading courses" />}
      {status === 'failed' && <ErrorState message={error} onRetry={() => dispatch(fetchCourses(qs))} />}
      {status === 'succeeded' && items.length === 0 && (
        <EmptyState title="No courses match your search" action={<button className="btn" onClick={clear}>Clear filters</button>}>
          Try a different keyword or remove a filter.
        </EmptyState>
      )}
      {status === 'succeeded' && items.length > 0 && (
        <>
          <ul className="grid">{items.map((c) => <li key={c.id}><CourseCard course={c} /></li>)}</ul>
          <Pagination page={page} pages={pages} onChange={(p) => { set('page', String(p)); window.scrollTo?.(0, 0); }} />
        </>
      )}
    </>
  );
}
