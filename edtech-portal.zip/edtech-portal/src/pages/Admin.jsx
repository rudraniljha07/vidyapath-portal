import { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { EmptyState, ErrorState, Loading } from '../components/States';
import { loadEnrolments, updateEnrolment } from '../store/enrolmentsSlice';
import { toggleRole } from '../store/userSlice';
import { useTitle } from '../utils';
export default function Admin() {
  useTitle('Coordinator dashboard');
  const dispatch = useDispatch();
  const role = useSelector((s) => s.user.role);
  const { items, status, error } = useSelector((s) => s.enrolments);
  useEffect(() => { if (role === 'coordinator') dispatch(loadEnrolments()); }, [dispatch, role]);
  if (role !== 'coordinator') return (
    <EmptyState title="Coordinator access required" action={<button className="btn" onClick={() => dispatch(toggleRole())}>Switch to coordinator view</button>}>
      This demo has no real login; switch roles to explore the dashboard.
    </EmptyState>
  );
  const pending = items.filter((e) => e.status === 'Pending').length;
  return (
    <>
      <h1>Coordinator dashboard</h1>
      {status === 'loading' && <Loading label="Loading enrolments" />}
      {status === 'failed' && <ErrorState message={error} onRetry={() => dispatch(loadEnrolments())} />}
      {status === 'succeeded' && items.length === 0 && <EmptyState title="No enrolment requests">New requests will show up here.</EmptyState>}
      {items.length > 0 && <>
        <p aria-live="polite">{items.length} enrolments · {pending} pending</p>
        <div className="scroll" tabIndex={0} role="region" aria-label="Enrolments table">
          <table>
            <caption className="sr-only">Enrolment requests</caption>
            <thead><tr><th scope="col">Learner</th><th scope="col">Course</th><th scope="col">Centre</th><th scope="col">Status</th></tr></thead>
            <tbody>{items.map((e) => (
              <tr key={e.id}>
                <th scope="row" className="wrap-text">{e.name}<br /><small>{e.email}</small></th>
                <td className="wrap-text">{e.courseTitle}</td><td>{e.centre}</td>
                <td><select aria-label={`Status for ${e.name}`} value={e.status} onChange={(ev) => dispatch(updateEnrolment({ id: e.id, status: ev.target.value }))}>
                  {['Pending', 'Confirmed', 'Cancelled'].map((s) => <option key={s}>{s}</option>)}</select></td>
              </tr>))}</tbody>
          </table>
        </div>
      </>}
    </>
  );
}
