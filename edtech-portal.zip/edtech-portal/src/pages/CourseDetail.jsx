import { useCallback, useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { getCourse } from '../api';
import { ErrorState, Loading } from '../components/States';
import { fmtDate, money, useTitle } from '../utils';
export default function CourseDetail() {
  const { id } = useParams();
  const [state, setState] = useState({ status: 'loading' });
  const load = useCallback(() => {
    setState({ status: 'loading' });
    getCourse(id).then((course) => setState({ status: 'ok', course })).catch((e) => setState({ status: 'error', error: e.message }));
  }, [id]);
  useEffect(() => { load(); }, [load]);
  useTitle(state.course?.title || 'Course');
  if (state.status === 'loading') return <Loading label="Loading course" />;
  if (state.status === 'error') return <ErrorState message={state.error} onRetry={load} />;
  const c = state.course;
  return (
    <article className="detail">
      <p><Link to="/courses">← All courses</Link></p>
      <h1 className="wrap-text">{c.title}</h1>
      <p className="tag">{c.category} · {c.level} · {c.mode}</p>
      <p>{c.description}</p>
      <dl className="facts">
        <div><dt>Fee</dt><dd>{money(c.fee)}</dd></div>
        <div><dt>Duration</dt><dd>{c.durationWeeks} weeks</dd></div>
        <div><dt>Starts</dt><dd>{fmtDate(c.startDate)}</dd></div>
        <div><dt>Centre</dt><dd>{c.centre}</dd></div>
        <div><dt>Instructor</dt><dd>{c.instructor}</dd></div>
        <div><dt>Rating</dt><dd>★ {c.rating}</dd></div>
        <div><dt>Seats left</dt><dd>{c.seatsLeft}</dd></div>
      </dl>
      {c.seatsLeft === 0
        ? <p className="badge full" role="status">This course is fully booked.</p>
        : <Link className="btn" to={`/courses/${c.id}/enrol`}>Enrol now</Link>}
    </article>
  );
}
