import { useEffect, useRef, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Link, useParams } from 'react-router-dom';
import { getCourse } from '../api';
import { BATCHES, CENTRES } from '../constants';
import { Field } from '../components/Field';
import { ErrorState, Loading } from '../components/States';
import { submitEnrolment } from '../store/enrolmentsSlice';
import { setUser } from '../store/userSlice';
import { validateStep } from '../validators';
import { useTitle } from '../utils';

const STEPS = ['Your details', 'Batch preference', 'Review'];
export default function Enrol() {
  useTitle('Enrol');
  const { id } = useParams();
  const dispatch = useDispatch();
  const user = useSelector((s) => s.user);
  const [course, setCourse] = useState(null);
  const [loadErr, setLoadErr] = useState(null);
  const [step, setStep] = useState(0);
  const [v, setV] = useState({ name: user.name, email: user.email, phone: user.phone, centre: '', batch: '', agree: false });
  const [errors, setErrors] = useState({});
  const [submitErr, setSubmitErr] = useState(null);
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(false);
  const heading = useRef(null);
  const formRef = useRef(null);

  useEffect(() => { getCourse(id).then(setCourse).catch((e) => setLoadErr(e.message)); }, [id]);
  useEffect(() => { heading.current?.focus(); }, [step, done, course]);

  if (loadErr) return <ErrorState message={loadErr} />;
  if (!course) return <Loading label="Loading course" />;
  if (course.seatsLeft === 0) return <div className="state"><h1>Fully booked</h1><p className="wrap-text">{course.title} has no seats left.</p><Link className="btn" to="/courses">Browse other courses</Link></div>;
  if (done) return (
    <div className="state"><h1 ref={heading} tabIndex={-1}>Enrolment request received</h1>
      <p className="wrap-text">Thank you, {v.name}. A coordinator will confirm your seat in {course.title} by email.</p>
      <Link className="btn" to="/profile">View my enrolments</Link></div>
  );

  const on = (k) => (e) => setV({ ...v, [k]: e.target.type === 'checkbox' ? e.target.checked : e.target.value });
  const fail = (errs) => {
    setErrors(errs);
    // move focus to the first invalid control
    setTimeout(() => formRef.current?.querySelector('[aria-invalid="true"]')?.focus(), 0);
  };
  const submit = async (e) => {
    e.preventDefault();
    const errs = validateStep(step, v);
    if (Object.keys(errs).length) return fail(errs);
    setErrors({});
    if (step < STEPS.length - 1) return setStep(step + 1);
    setBusy(true); setSubmitErr(null);
    try {
      await dispatch(submitEnrolment({ courseId: course.id, name: v.name.trim(), email: v.email.trim(), phone: v.phone.trim(), centre: v.centre, batch: v.batch })).unwrap();
      dispatch(setUser({ name: v.name.trim(), email: v.email.trim(), phone: v.phone.trim() }));
      setDone(true);
    } catch (err) { setSubmitErr(err.message); } finally { setBusy(false); }
  };
  const n = Object.keys(errors).length;

  return (
    <>
      <p><Link to={`/courses/${course.id}`}>← Back to course</Link></p>
      <h1 className="wrap-text">Enrol: {course.title}</h1>
      <ol className="steps" aria-label="Progress">
        {STEPS.map((s, i) => <li key={s} aria-current={i === step ? 'step' : undefined} className={i <= step ? 'on' : ''}>{i + 1}. {s}</li>)}
      </ol>
      <form noValidate onSubmit={submit} ref={formRef} className="form">
        <h2 ref={heading} tabIndex={-1}>{STEPS[step]}</h2>
        {n > 0 && <div role="alert" className="summary">Please fix {n} error{n > 1 ? 's' : ''} below.</div>}
        {submitErr && <div role="alert" className="summary">{submitErr}</div>}
        {step === 0 && <>
          <Field id="name" label="Full name" autoComplete="name" value={v.name} onChange={on('name')} error={errors.name} required />
          <Field id="email" label="Email address" type="email" autoComplete="email" value={v.email} onChange={on('email')} error={errors.email} required />
          <Field id="phone" label="Mobile number" type="tel" inputMode="numeric" autoComplete="tel-national" hint="10 digits, no country code" value={v.phone} onChange={on('phone')} error={errors.phone} required />
        </>}
        {step === 1 && <>
          <Field id="centre" label="Preferred centre" as="select" value={v.centre} onChange={on('centre')} error={errors.centre} required>
            <option value="">Select a centre</option>{CENTRES.map((c) => <option key={c}>{c}</option>)}
          </Field>
          <Field id="batch" label="Batch timing" as="select" value={v.batch} onChange={on('batch')} error={errors.batch} required>
            <option value="">Select a timing</option>{BATCHES.map((c) => <option key={c}>{c}</option>)}
          </Field>
        </>}
        {step === 2 && <>
          <dl className="facts">{[['Name', v.name], ['Email', v.email], ['Mobile', v.phone], ['Centre', v.centre], ['Batch', v.batch]].map(([k, x]) => <div key={k}><dt>{k}</dt><dd className="wrap-text">{x}</dd></div>)}</dl>
          <div className="field check">
            <input id="agree" name="agree" type="checkbox" checked={v.agree} onChange={on('agree')} aria-invalid={errors.agree ? 'true' : undefined} aria-describedby={errors.agree ? 'agree-err' : undefined} />
            <label htmlFor="agree">I agree to the fee and refund terms</label>
            {errors.agree && <p id="agree-err" className="error">{errors.agree}</p>}
          </div>
        </>}
        <div className="actions">
          {step > 0 && <button type="button" className="btn secondary" onClick={() => { setErrors({}); setStep(step - 1); }}>Back</button>}
          <button className="btn" disabled={busy}>{step === STEPS.length - 1 ? (busy ? 'Submitting…' : 'Submit enrolment') : 'Next'}</button>
        </div>
      </form>
    </>
  );
}
