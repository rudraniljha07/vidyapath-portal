export const CATEGORIES = ['Engineering Entrance','Medical Entrance','Foundation','Coding','Languages','Commerce'];
export const LEVELS = ['Beginner','Intermediate','Advanced'];
export const MODES = ['Classroom','Online','Hybrid'];
export const CENTRES = ['Koramangala','Indiranagar','Jayanagar','Whitefield','HSR Layout'];
export const BATCHES = ['Weekday morning','Weekday evening','Weekend'];
export const SORTS = [
  ['', 'Relevance'], ['fee-asc', 'Fee: low to high'], ['fee-desc', 'Fee: high to low'],
  ['rating', 'Top rated'], ['start', 'Starting soonest'],
];
export const PAGE_SIZE = 9;
