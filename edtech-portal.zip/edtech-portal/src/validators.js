const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const PHONE = /^[6-9]\d{9}$/; // Indian mobile numbers
export function validateStep(step, v) {
  const e = {};
  if (step === 0) {
    if (!v.name.trim() || v.name.trim().length < 2) e.name = 'Enter your full name (at least 2 characters).';
    if (!EMAIL.test(v.email.trim())) e.email = 'Enter a valid email address, e.g. name@example.com.';
    if (!PHONE.test(v.phone.trim())) e.phone = 'Enter a 10-digit mobile number starting with 6, 7, 8 or 9.';
  }
  if (step === 1) {
    if (!v.centre) e.centre = 'Choose a centre.';
    if (!v.batch) e.batch = 'Choose a batch timing.';
  }
  if (step === 2 && !v.agree) e.agree = 'You must agree to the terms to continue.';
  return e;
}
