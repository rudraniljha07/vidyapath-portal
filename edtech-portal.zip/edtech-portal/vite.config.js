import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
export default defineConfig({
  plugins: [react()],
  build: { target: 'es2020' },
  test: { environment: 'jsdom', globals: true, setupFiles: './src/test/setup.js', css: false },
});
