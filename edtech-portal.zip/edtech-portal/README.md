# VidyaPath – Course listing & enrolment portal

React 18 + Vite + Redux Toolkit + React Router 6. Mock REST API via **MSW** (runs in the browser, so the static site deploys with no backend). Tests: Vitest + React Testing Library (Jest-compatible API).

## Run
```bash
npm install
npm run dev      # http://localhost:5173
npm test         # 18 component/integration tests
npm run build && npm run preview
```
Deploy: connect the repo to Netlify (`netlify.toml` is included, with SPA redirect) or Vercel (framework: Vite).

## Screens & wireframes
`wireframes.svg` – six mobile-first wireframes: Home, Listing, Detail, Enrol form, Profile, Admin.

## Structure
```
src/
  pages/        Home, Courses, CourseDetail, Enrol, Profile, Admin   (all route-level, lazy-loaded)
  components/   Layout (skip link, focus management), CourseCard, Pagination, Field, States (Loading/Empty/Error)
  store/        coursesSlice, enrolmentsSlice, userSlice
  mocks/        data.js (seed + edge cases), handlers.js (REST), browser.js / server.js
  validators.js pure step validation, shared by the form AND the mock API
  test/         RTL + MSW tests
```

## State choices (be ready to explain)
- **URL = filter state.** Search, category, level, mode, sort and page live in the query string (`useSearchParams`). Links are shareable, Back works, and there is a single source of truth.
- **Redux Toolkit = shared server data.** `courses` (list + status/error) and `enrolments` are used across pages (Profile, Admin, Enrol) so they sit in the store. Thunks give `idle/loading/succeeded/failed` for free. A `requestId` guard drops stale responses when the user types or filters quickly.
- **Local state = ephemeral UI.** Course detail data and the multi-step form values live in the component; nothing else needs them.
- **`user` slice** holds a fake session (name, email, role) – enough to demo the learner/coordinator views without auth.

## Edge-case data
Very long title (id 7, also fully booked), missing image (ids divisible by 4), broken image URL (id 5 → falls back to placeholder), full courses (ids 7/14/21/28), empty results via search, forced error via `?fail=1` on the API or a server override in tests.

## Accessibility
Skip link; focus moved to `<main>` on route change and to the step heading / first invalid field in the form; labelled controls with `aria-invalid` + `aria-describedby`; `role="alert"` error summary; `aria-current` on stepper, nav and pagination; live region for result counts; 44px touch targets; visible focus ring; `prefers-reduced-motion`; text colours ≥ 4.5:1 (e.g. #1d4ed8 on white ≈ 6.7:1, #4b5563 ≈ 7.5:1); scrollable table region is keyboard-focusable.

## Test results
`4 files, 18 tests passed` – listing (loading, filter, sort, pagination, empty, error + retry, missing image), enrolment (validation, focus, 3-step submit, full course), detail (404, long title), admin guard + status update, profile, validators.

## Not yet done / to do before submission
- [ ] Push to GitHub, deploy to Netlify/Vercel, add live URL here
- [ ] Run Lighthouse (mobile) on the live URL and paste scores
- [ ] Add screenshots to `/docs` and link them here
- [ ] PWA/offline (stretch): MSW already owns the root service-worker scope, so add Workbox via `vite-plugin-pwa` with `importScripts('mockServiceWorker.js')`, or switch to a real API first. Route-level lazy loading **is** done.
